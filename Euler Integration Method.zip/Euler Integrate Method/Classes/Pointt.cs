﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Pointt
    {
        public double X;
        public double Y;

        public Pointt (double x, double y)
        {
            this.X = x;
            this.Y = y;
        }
    }
}
